export function chat_msg(msg) {
    ChatLib.chat("&a[DUU]&a " + msg);
}

export function chat_error(msg) {
    ChatLib.chat("&c[DUU]&c " + msg);
}
